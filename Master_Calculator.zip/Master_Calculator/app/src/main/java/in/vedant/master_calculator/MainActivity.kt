package `in`.vedant.master_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    override fun onCreate(savedInstanceState: Bundle?) {
        
        var n1:Int
        var n2:Int
        var op:Int
        n1 = 0
        n2 = 0
        op = 0
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //*******************************************************************************************************************************
        num1.setOnClickListener(View.OnClickListener {
            View1.append("1")
        })
        num2.setOnClickListener(View.OnClickListener {
            View1.append("2") })
        num3.setOnClickListener(View.OnClickListener {
            View1.append("3") })
        num4.setOnClickListener(View.OnClickListener {
            View1.append("4") })
        num5.setOnClickListener(View.OnClickListener {
            View1.append("5") })
        num6.setOnClickListener(View.OnClickListener {
            View1.append("6") })
        num7.setOnClickListener(View.OnClickListener {
            View1.append("7") })
        num8.setOnClickListener(View.OnClickListener {
            View1.append("8") })
        num9.setOnClickListener(View.OnClickListener {
            View1.append("9") })
        num0.setOnClickListener(View.OnClickListener {
            View1.append("0") })
        //*******************************************************************************************************************************
        numdel.setOnClickListener(View.OnClickListener
        {
            View1.setText(View1.text.substring(0,View1.text.length-1))
        })
        numaddorminus.setOnClickListener(View.OnClickListener
        {
          View1.setText((View1.text.toString().toInt() * -1).toString())
        })
        numAC.setOnClickListener(View.OnClickListener
        {
            View1.setText("")
        })
        numplus.setOnClickListener(View.OnClickListener {
            n1=View1.text.toString().toInt()
            op=1
            View1.setText("")
        })
        nummulti.setOnClickListener(View.OnClickListener {
            n1=View1.text.toString().toInt()
            op=3
            View1.setText("")
        })
        numminus.setOnClickListener(View.OnClickListener {
            n1=View1.text.toString().toInt()
            op=2
            View1.setText("")
        })
        numdivide.setOnClickListener(View.OnClickListener {
            n1=View1.text.toString().toInt()
            op=4
            View1.setText("")
        })
        //*******************************************************************************************************************************
        numequal.setOnClickListener(View.OnClickListener {
            n2=View1.text.toString().toInt()
            if (op == 1){
                View1.setText((n1+n2).toString())
            }
            else if (op == 2){
                View1.setText((n1-n2).toString())
            }
            else if (op == 3){
                View1.setText((n1*n2).toString())
            }
            else if (op == 4){
                View1.setText((n1/n2).toString())
            }

        })


    }
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



}
